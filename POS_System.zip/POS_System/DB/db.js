const data = "POS_Customer";

export function saveCustomerDB(new_customer) {
    let pre_data = localStorage.getItem(data);

    let customer_arr2 = [];

    if (pre_data) {
        customer_arr2 = JSON.parse(pre_data);
    }

    customer_arr2.push(new_customer);
    localStorage.setItem(data, JSON.stringify(customer_arr2));
}

export function getCustomerDB() {
    let pre_data = localStorage.getItem(data);

    let customer_arr2 = [];

    if (pre_data) {
        customer_arr2 = JSON.parse(pre_data);
    }

    return customer_arr2;
}